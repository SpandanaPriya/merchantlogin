export class Merchant{
uName: string;
pwd:string;





}