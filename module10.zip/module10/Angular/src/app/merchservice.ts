import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Merchant} from './merchant';



@Injectable({
  providedIn: 'root'
})
export class merchserviceService {
  id: number;


  constructor(private httpClient: HttpClient) { }
  login(uName, pwd): Observable<number> {
    let url = 'http://localhost:9002/login/' + uName + '/' + pwd;

   return this.httpClient.get<number>(url);
  }

  getid() {
    return this.id;
  }

  setid(id: number) {
    this.id = id;
  }
}
