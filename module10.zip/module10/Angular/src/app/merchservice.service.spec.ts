import { TestBed } from '@angular/core/testing';

import { merchserviceService } from './merchservice';

describe('merchserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: merchserviceService = TestBed.get(merchserviceService);
    expect(service).toBeTruthy();
  });
});
