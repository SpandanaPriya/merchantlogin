package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
//@Table(name="custo123")
public class Merchant {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int merchant_id;
	public String uName;
	public String pwd;
	public Merchant() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getMerchant_id() {
		return merchant_id;
	}


	public void setMerchant_id(int merchant_id) {
		this.merchant_id = merchant_id;
	}


	

	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
}
