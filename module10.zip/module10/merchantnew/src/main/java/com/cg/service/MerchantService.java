package com.cg.service;

import java.util.List;



public interface MerchantService {
	 public int loginByUsername(String uName, String pwd);

}
