package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.service.MerchantService;

@CrossOrigin("http://localhost:4200")
@RestController
public class MerchantController {
	@Autowired
	MerchantService ser;
	
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) {
  		return ser.loginByUsername(username, password);
  	}
	
	
	  
	  
}
